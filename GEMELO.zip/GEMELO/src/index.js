//correr con npm run dev


import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x222222);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(2, 0, 8);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Luces
const light = new THREE.DirectionalLight(0xffffff, 1);
light.position.set(5, 5, 5);
scene.add(light);
scene.add(new THREE.AmbientLight(0x404040));

// OrbitControls
const controls = new OrbitControls(camera, renderer.domElement);

// Variables para animación
let mixer;
let model;
const clock = new THREE.Clock();

// Cargar modelo GLB
const loader = new GLTFLoader();
loader.load(
  '/modelo1.glb',
  function (gltf) {
    model = gltf.scene;
    model.scale.set(0.5, 0.5, 0.5);
    scene.add(model);

    // Inicializar mixer de animaciones
    mixer = new THREE.AnimationMixer(model);

    // Mostrar animaciones disponibles en consola
    console.log('Animaciones disponibles:', gltf.animations.map(a => a.name));

    // Guardar animaciones
    model.animations = gltf.animations;

    console.log('Modelo cargado');
  },
  undefined,
  function (error) {
    console.error('Error al cargar el modelo:', error);
  }
);

// Función para reproducir animación
function reproducirAnimacion(nombreAnimacion) {
  if (mixer && model && model.animations) {
    const originalClip = THREE.AnimationClip.findByName(model.animations, nombreAnimacion);
    if (originalClip) {
      // Clonamos el clip original para no modificar el original
      const durationLimit = 5.0; // 2 segundos = 60 frames si trabajas a 30 FPS
      const limitedTracks = originalClip.tracks.map(track => {
        const times = [];
        const values = [];

        for (let i = 0; i < track.times.length; i++) {
          if (track.times[i] <= durationLimit) {
            times.push(track.times[i]);
            const stride = track.getValueSize();
            for (let j = 0; j < stride; j++) {
              values.push(track.values[i * stride + j]);
            }
          } else {
            break;
          }
        }

        return new THREE.KeyframeTrack(track.name, times, values);
      });

      const clipCortado = new THREE.AnimationClip(`${nombreAnimacion}_cortado`, durationLimit, limitedTracks);
      const action = mixer.clipAction(clipCortado);
      action.reset().play();
      action.setLoop(THREE.LoopOnce);      // Solo una vez
      action.clampWhenFinished = true;     // Se queda en el último frame
    } else {
      console.warn(`Animación "${nombreAnimacion}" no encontrada`);
    }
  }
}

// Evento botón
document.getElementById('animar').addEventListener('click', () => {
  reproducirAnimacion('Acción.005'); 
  reproducirAnimacion('LARGO_1_IZQ_acción');
  reproducirAnimacion('LARGO_2_IZQ_acción');
  reproducirAnimacion('Acción'); 
  reproducirAnimacion('LARGO_2_DERE_acción'); 
  reproducirAnimacion('LARGO_3_DERE_acción'); 
  reproducirAnimacion('GARRA_COMPLE.002_acción'); // Usa exactamente el nombre que aparece en Blender
});

// Loop de render
function animate() {
  requestAnimationFrame(animate);
  const delta = clock.getDelta();
  if (mixer) mixer.update(delta);
  controls.update();
  renderer.render(scene, camera);
}
animate();

// Ajustar al cambiar tamaño de ventana
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
